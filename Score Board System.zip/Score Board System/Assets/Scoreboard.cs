
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class Scoreboard : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TMP_Text scoreText;

    [Header("Score Settings")]
    [SerializeField] private int pointsPerPress = 30;
    [SerializeField] private float countDuration = 0.8f;

    private int currentScore = 0;
    private int displayedScore = 0;
    private Coroutine countCoroutine;

    private void Start()
    {
        scoreText.text = "Score: " + currentScore.ToString();
    }

    private void Update()
    {
        if (Keyboard.current != null &&
            Keyboard.current.eKey.wasPressedThisFrame)
        {
            AddScore(pointsPerPress);
        }
    }

    public void AddScore(int amount)
    {
        currentScore += amount;

        if (countCoroutine != null)
            StopCoroutine(countCoroutine);

        countCoroutine = StartCoroutine(AnimateScore());
    }

    private IEnumerator AnimateScore()
    {
        int startScore = displayedScore;
        int targetScore = currentScore;
        float elapsed = 0f;

        while (elapsed < countDuration)
        {
            elapsed += Time.deltaTime;

            float t = Mathf.Clamp01(elapsed / countDuration);

            // fast at first slower near the end
            float easedT = 1f - Mathf.Pow(1f - t, 3f);

            displayedScore = Mathf.RoundToInt(
                Mathf.Lerp(startScore, targetScore, easedT)
            );

            scoreText.text = "Score: " + displayedScore.ToString();

            yield return null;
        }

        displayedScore = targetScore;
        scoreText.text = "Score: " + displayedScore.ToString();

        countCoroutine = null;
    }
}
