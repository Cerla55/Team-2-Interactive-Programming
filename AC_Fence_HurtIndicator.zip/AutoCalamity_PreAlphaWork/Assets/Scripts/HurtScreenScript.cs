using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class HurtScreenScript : MonoBehaviour
{
    [SerializeField] private float fadeDuration = 1.25f;
    [SerializeField] private float displayDuration = 0.5f;

    private Image hurtImage;
    private Coroutine hurtCoroutine;

    void Awake()
    {
        hurtImage = GetComponent<Image>();

        if (hurtImage != null)
        {
            Color color = hurtImage.color;
            color.a = 0f;
            hurtImage.color = color;
        }
        else
        {
            Debug.LogError("No Image component found!");
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            TriggerHurtIndicator(); 
        }
    }

    public void TriggerHurtIndicator()  ////Method to call when player is hurt
    {
        if (hurtImage == null) return;

        if (hurtCoroutine != null)
        {
            StopCoroutine(hurtCoroutine);
        }

        hurtCoroutine = StartCoroutine(HurtIndicator());
    }

    private IEnumerator HurtIndicator()
    {
        yield return StartCoroutine(Fade(0f, 1f));

        yield return new WaitForSeconds(displayDuration);

        yield return StartCoroutine(Fade(1f, 0f));

        hurtCoroutine = null;
    }

    private IEnumerator Fade(float startAlpha, float targetAlpha)
    {
        float elapsed = 0f;

        Color color = hurtImage.color;

        while (elapsed < fadeDuration)
        {
            elapsed += Time.deltaTime;

            color.a = Mathf.Lerp(startAlpha, targetAlpha, elapsed / fadeDuration);
            hurtImage.color = color;

            yield return null;
        }

        color.a = targetAlpha;
        hurtImage.color = color;
    }
}